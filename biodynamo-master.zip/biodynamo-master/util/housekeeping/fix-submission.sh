#!/bin/sh
# -----------------------------------------------------------------------------
#
# Copyright (C) 2021 CERN & Newcastle University for the benefit of the
# BioDynaMo collaboration. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
#
# See the LICENSE file distributed with this work for details.
# See the NOTICE file distributed with this work for additional information
# regarding copyright ownership.
#
# -----------------------------------------------------------------------------

# This script invokes the necessary Makefile targets to fix errors in a code
# submission
# Arguments:
#   $1: cmake binary directory

BINARY_DIR=$1
cmake --build $BINARY_DIR --target fetch-master
cmake --build $BINARY_DIR --target tidy
cmake --build $BINARY_DIR --target format
