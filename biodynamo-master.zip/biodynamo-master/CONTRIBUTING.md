# Contributing Guidelines

You can find our contributing guidelines in our [developer guide](https://biodynamo.github.io/dev/contribute/)
